package main;

public final class User {
    private User(){}
    public static final String URL = "jdbc:postgresql://localhost:5432/NAZWA_BAZY";
    public static final String USERNAME = "LOGIN";
    public static final String PASSWORD = "HASLO";
}
