package main;

public final class User {
    private User(){}
    public static final String URL = "jdbc:postgresql://localhost:5432/sipuk";
    public static final String USERNAME = "sipuk";
    public static final String PASSWORD = "123";
}
